function bienvenida(){
    document.write("<br><br><br>");
    document.write("<h3>Cada Jojo es único y especial</h3>");
}
